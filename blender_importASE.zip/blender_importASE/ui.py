import bpy
from ase import Atoms
from .import_cubefiles import (cube2vol, chgcar2vol, is_vasp_density, read_vasp_density,
                               is_ams_tape41, read_tape41, tape41_import)
from .utils import atomcolors, group_atoms
from .drawobjects import draw_atoms, draw_bonds, draw_unit_cell, draw_longbonds
from .trajectory import move_atoms, move_bonds,move_longbonds
from .node_networks.nodes_atoms_and_bonds import set_atoms_node_group, atoms_and_bonds, read_structure
from .node_networks.supercell import make_supercell
from .node_networks.bond_mat import create_bondmat
from .node_networks.outline import outline_objects
from .node_networks.bond_node import make_bonds
from .node_networks.compat import set_mod_input
from .node_networks.hide_atoms import hide_atoms
from .node_networks.adp_nodes import store_adps, setup_adp_inputs, add_adp_rings
from .adp import read_atoms, anisotropic_adps
import time


def import_ase_molecule(filepath, filename, overwrite=True, add_supercell=True, resolution=32, colorbonds=False, long_bonds=False, color=0.2, scale=1,
                        unit_cell=False,
                        representation="Balls'n'Sticks",
                        read_density=True, shift_cell=False,
                        imageslice=1, frame_interpolation=1,
                        animate = True, outline = True,
                        adps=True, adp_probability=0.5, hydrogen_adps=False, **kwargs):
    """adps: with the nodes representation, draw the atoms as thermal
    ellipsoids with principal-axis rings when the file carries anisotropic
    displacement parameters (CIF, SHELX .res / .ins; see adp.py) - ignored
    for files without them. adp_probability sets the ellipsoid level,
    hydrogen_adps whether hydrogens get one too."""
    # Read in the structure
    start=time.time()
    modifier_counter = 0
    modifier_chosen=''
    vasp_density = None
    tape41_volumes = None
    if is_vasp_density(filename):
        # CHGCAR-like files can't be read by ase.io.read (the POSCAR header
        # is followed by the density grid); read atoms and grid in one pass
        vasp_density = read_vasp_density(filepath)
        atoms = list(vasp_density.atoms)
    elif is_ams_tape41(filename):
        # TAPE41 is a binary KF file, not an ase.io format at all - atoms
        # and every requested volume come from the same KFFile pass
        tape41_atoms, tape41_volumes = read_tape41(filepath)
        atoms = [tape41_atoms]
    else:
        # ase.io.read, plus SHELX files, keeping a CIF's atom-site tags
        atoms = read_atoms(filepath, index=':')
    end_read=time.time()
    print('Time to read file: ',end_read-start)
    
    # Handle trajectory files
    trajectory = False
    if isinstance(atoms[0],Atoms) and len(atoms) > 1:
        trajectory = True
        TRAJECTORY=atoms.copy()
        # Use the fullest frame as the setup reference so materials and the
        # per-element hide toggles cover every atom type in the trajectory,
        # including molecules that spawn in on later frames. (The first frame
        # used to be dropped here, which cut the opening state of the run.)
        atoms=max(atoms, key=len)
        if animate is False:
            atoms = TRAJECTORY[-1]
        else:
            # frame_interpolation spaces the images out over the timeline, so
            # the last image sits at (n_images - 1) * frame_interpolation
            n_images = len(TRAJECTORY[::imageslice])
            bpy.data.scenes['Scene'].frame_end = (
                (n_images - 1) * frame_interpolation + 1 if frame_interpolation > 1
                else n_images)
            bpy.data.scenes['Scene'].frame_start = 0
            bpy.data.scenes['Scene'].frame_current = 0
            if frame_interpolation > 1 and len({len(f) for f in TRAJECTORY}) > 1:
                # Interpolating between two images with different atom counts
                # is ill-defined: an atom that only exists in the later image
                # is parked far away in the earlier one, so the in-between
                # frames slide it in from that parking position. Images
                # themselves are still exact; only the generated frames
                # between a spawn/removal are affected.
                print('WARNING: frame-interpolation > 1 on a trajectory whose '
                      'atom count changes - atoms that appear or disappear will '
                      'slide in/out across the interpolated frames. The imported '
                      'images themselves are unaffected.')
    elif len(atoms) == 1:
        atoms=atoms[0]
    
    # If overwrite is chosen, set representation to nodes for animations
    if overwrite and representation != 'nodes' and animate and trajectory:
        representation = 'nodes'
    
    # When importing molecules from AMS, the resulting atoms do not lie in the unit cell since AMS uses unit cells centered around 0
    cell = atoms.cell
    shift_vector = 0.5 * cell[0] + 0.5 * cell[1] + 0.5 * cell[2]
    if shift_cell:
        atoms.positions += shift_vector

    # Set up materials
    atomcolor=atomcolors()
    atomcolor.setup_materials(atoms, colorbonds=colorbonds)        
    my_coll = bpy.data.collections.new(name=atoms.get_chemical_formula() + '_' + filename.split('.')[0])
    bpy.context.scene.collection.children.link(my_coll)
    layer_collection = bpy.context.view_layer.layer_collection.children[my_coll.name]
    bpy.context.view_layer.active_layer_collection = layer_collection

    # Draw the atoms and bonds
    if representation != '3D_print' and representation != 'nodes':
        group_atoms(atoms)
        list_of_atoms=draw_atoms(atoms, scale=scale,resolution=resolution ,representation=representation)
        if representation != 'VDW':
            if long_bonds:
                list_of_bonds,nl,bondlengths=draw_longbonds(atoms,resolution=resolution, colorbonds=colorbonds)
            else:
                list_of_bonds,nl=draw_bonds(atoms,resolution=resolution)
    if representation == 'nodes':
        if animate and trajectory:
            obj,mesh=read_structure(TRAJECTORY[::imageslice],atoms.get_chemical_formula() + '_' + filename.split('.')[0],animate=True,frame_interpolation=frame_interpolation)
        else:
            obj,mesh=read_structure(atoms,atoms.get_chemical_formula() + '_' + filename.split('.')[0],animate=False)
        # ellipsoids for a static structure whose file has an anisotropic
        # displacement table; nothing changes for any other file
        U = None if (animate and trajectory) or not adps else anisotropic_adps(atoms)
        if U is not None:
            store_adps(mesh, U)
        print(f'add hide modifier to GeometryNodes{modifier_chosen}')
        hide_atoms(obj,atoms,modifier='GeometryNodes'+modifier_chosen)
        modifier_counter += 1
        modifier_chosen=f'.00{modifier_counter}'
        if add_supercell:
            print(f'add supercell modifier to GeometryNodes{modifier_chosen}')
            added=make_supercell([obj], atoms, 'GeometryNodes'+modifier_chosen,representation=representation)
            if added:
                modifier_counter += 1
                modifier_chosen=f'.00{modifier_counter}'
        set_atoms_node_group()
        elements_name='_'.join(list(set(atoms.get_chemical_symbols())))
        bondmat=create_bondmat(colorbonds=colorbonds,name=elements_name)
        print(f'add atoms_and_bonds modifier to GeometryNodes{modifier_chosen}')
        atoms_from_verts = atoms_and_bonds(obj,atoms,'GeometryNodes'+modifier_chosen,bondmat=bondmat,
                                           with_adps=U is not None)
       
        mod = bpy.context.object.modifiers['GeometryNodes'+modifier_chosen]
        mod.node_group = atoms_from_verts
        set_mod_input(mod, "Socket_2", 0.66)
        set_mod_input(mod, "Socket_3", 0.1)
        set_mod_input(mod, "Socket_4", resolution)
        if U is not None:
            setup_adp_inputs(mod, adp_probability, hydrogen_adps)
        modifier_counter += 1
        modifier_chosen=f'.00{modifier_counter}'
        

        #bond_nodes = bond_nodes_node_group(atoms, atoms_from_verts)
    if representation == '3D_print':
       
        sec_coll = bpy.data.collections.new(name='atoms')
        my_coll.children.link(sec_coll)
        seclayer_collection = layer_collection.children[sec_coll.name]
        bpy.context.view_layer.active_layer_collection = seclayer_collection
        group_atoms(atoms)
        list_of_atoms=draw_atoms(atoms, scale=scale,resolution=resolution ,representation=representation)
        bpy.context.view_layer.active_layer_collection = layer_collection
        bonds_obj = make_bonds(modifier='GeometryNodes')
        set_mod_input(bonds_obj.modifiers['GeometryNodes'], "Socket_1", 0.60)
        set_mod_input(bonds_obj.modifiers['GeometryNodes'], "Socket_2", 0.1)
        set_mod_input(bonds_obj.modifiers['GeometryNodes'], "Socket_3", sec_coll)
        

    # Draw the unit cell
    if unit_cell is True and atoms.pbc.all() is not False:
        draw_unit_cell(atoms)

    # Read in density
    if read_density:
        density_objs = []
        if filename.lower().endswith('.cube'):
            density_objs = [cube2vol(filepath,modifier='GeometryNodes')]
        elif vasp_density is not None:
            # total charge density, plus the spin difference if spin-polarized
            density_objs = chgcar2vol(filepath,modifier='GeometryNodes',density=vasp_density)
        elif tape41_volumes is not None:
            # one volume object per KF entry (e.g. every requested NOCV pair)
            density_objs = tape41_import(filepath,filename,modifier='GeometryNodes',found=tape41_volumes)
        if density_objs:
            modifier_chosen=f'.00{modifier_counter}'
            if shift_cell is True:
                for density_obj in density_objs:
                    density_obj.location.x += shift_vector[0]
                    density_obj.location.y += shift_vector[1]
                    density_obj.location.z += shift_vector[2]

    # Handle animation
    if trajectory is True and animate is True:
        if representation != 'nodes' and representation != '3D_print':

            move_atoms(TRAJECTORY,list_of_atoms,imageslice,frame_interpolation)
            if representation != 'VDW':
                if long_bonds is True:
                    move_longbonds(TRAJECTORY,list_of_bonds,nl,bondlengths,imageslice,frame_interpolation)
                else:
                    move_bonds(TRAJECTORY,list_of_bonds,nl,imageslice,frame_interpolation)
        if representation == '3D_print':
            print("generating trajectory for 3D_print")
            move_atoms(TRAJECTORY,list_of_atoms,imageslice,frame_interpolation)
    end=time.time()
    print('Time to import atoms_object: ',end-end_read)

    if outline:
        print(f'add outline modifier to GeometryNodes{modifier_chosen}')
        if representation != 'nodes' and representation != '3D_print' and representation != 'VDW':
            outline_objects(list_of_atoms + list_of_bonds,modifier='GeometryNodes'+modifier_chosen)
            modifier_counter += 1
            modifier_chosen=f'.00{modifier_counter}'
             
        if representation == '3D_print':
            outline_objects([bonds_obj],modifier='GeometryNodes.001')
            outline_objects(list_of_atoms,modifier='GeometryNodes')
            modifier_counter += 1
            modifier_chosen=f'.00{modifier_counter}'
            
        if representation == 'nodes':
            outline_objects([obj],modifier='GeometryNodes'+modifier_chosen)
    if representation == 'nodes' and U is not None:
        # last on the stack: sweep the ADP ring curves past the outline
        add_adp_rings(obj)
        if representation == 'VDW':
            outline_objects(list_of_atoms,modifier='GeometryNodes'+modifier_chosen)
            modifier_counter += 1
            modifier_chosen=f'.00{modifier_counter}'

    if add_supercell:
        if representation == '3D_print':
            added=make_supercell(list_of_atoms, atoms, 'GeometryNodes'+modifier_chosen,representation=representation)
            if added:
                print(f'added supercell to GeometryNodes{modifier_chosen}')
                modifier_counter += 1
                modifier_chosen=f'.00{modifier_counter}'
        
        if representation == 'VDW':
            added=make_supercell(list_of_atoms, atoms, 'GeometryNodes'+modifier_chosen,representation=representation)       
        
        if representation == 'licorice' or representation == "Balls'n'Sticks":
            added=make_supercell(list_of_atoms, atoms, 'GeometryNodes'+modifier_chosen,representation=representation) 
    
    
    END_END=time.time()
    print('modifier time: ',END_END-end)

            
